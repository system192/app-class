import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:audioplayers/audioplayers.dart';

final player=AudioPlayer()..setReleaseMode(ReleaseMode.loop);

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ClipPath example',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primarySwatch: Colors.green,),
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {

  final tabs=[
    Screen1(),
    Screen2(),
    Screen3(),
    Screen4(),
  ];

  int previousIndex=0;
  int currentIndex=0;

  @override
  Widget build(BuildContext context) {
    if (currentIndex==0) player.play(AssetSource("1.mp3"));
    return Scaffold(
      appBar: AppBar(title: Text('我的自傳'),
        centerTitle: true,),
      body: tabs[currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        backgroundColor: Colors.blue,
        selectedItemColor: Colors.white,
        selectedFontSize: 18,
        unselectedFontSize: 14,
        iconSize: 30,
        currentIndex: currentIndex,
        items: [
          BottomNavigationBarItem(icon: currentIndex==0?Image.asset('assets/ic.png', width: 40, height: 40,):Image.asset('assets/ic.png', width: 30, height: 30,), label: '自我介紹',),
          BottomNavigationBarItem(icon: Icon(Icons.school), label: '學習歷程',),
          BottomNavigationBarItem(icon: Icon(Icons.scale_outlined), label: '學習計畫',),
          BottomNavigationBarItem(icon: Icon(Icons.engineering), label: '專業方向',),
        ],
        onTap: (index) {
          setState(() {
            previousIndex=currentIndex;
            currentIndex=index;
            if (index==0) {
              if (previousIndex==currentIndex) player.resume();
              player.stop();
              player.play(AssetSource("1.mp3"));
            }
            if (index==1) {
              if (previousIndex==currentIndex) player.resume();
              player.stop();
              player.play(AssetSource("2.mp3"));
            }
            if (index==2) {
              if (previousIndex==currentIndex) player.resume();
              player.stop();
              player.play(AssetSource("3.mp3"));
            }
            if (index==3) {
              if (previousIndex==currentIndex) player.resume();
              player.stop();
              player.play(AssetSource("4.mp3"));
            }
          });
        },
      ),

    );
  }
}

class Screen1 extends StatelessWidget {
  Screen1({super.key});

  String s1='我叫楊程凱，出生於桃園市。從小，我便對大自然和科技有著濃厚的興趣，這些興趣也成為我成長中不可或缺的一部分。'
  '我特別喜歡喝茶。在品味不同種類的茶葉時，我總能感受到那種幽靜與平和。茶道教會了我如何靜心，讓我能在繁忙的學業和工作中找到片刻的寧靜。這種靜心的能力，在我研究電子工程學科時尤其重要，因為它讓我能夠專注於複雜的理論和實驗中，並深入理解其中的奧妙。'
  '除了喝茶，我還熱愛登山。每次登上山頂，俯瞰腳下的美景，我都能感受到一種由衷的喜悅和滿足。登山不僅是對身體的鍛煉，更是對心靈的洗滌。這種不懈攀登的精神，也深深影響了我的學術研究和職業生涯。無論是在大學期間的科研項目，還是工作中的技術挑戰，我總是秉持著這種登山精神，努力突破自己，追求卓越。'
  '在大學時期，我選擇了電子工程作為我的專業，這個決定源於我對科技的熱愛和探索精神。在學習過程中，我發現電子工程不僅僅是對技術的掌握，更需要一種細心和專注的態度，這與我在喝茶時體會到的靜心和在登山中培養的毅力完美結合。在研究和實驗中，這些品質幫助我克服了重重困難，使我能夠不斷創新，追求更高的目標。'
  '總的來說，我的興趣和學科相輔相成，喝茶讓我學會靜心，登山讓我磨練意志，而電子工程則為我提供了無限的探索空間。展望未來，我將繼續保持這種熱情和態度，在科技領域不斷前行，實現我的夢想和價值。';

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        children: [
          //放標題
          Padding(
            padding: EdgeInsets.fromLTRB(20, 30, 20, 20),
            child: Text('Who an I', style: TextStyle(fontSize: 30,
                fontWeight: FontWeight.bold),),
          ),
          //自傳部分
          Container(
            padding: EdgeInsets.all(20),
            margin: EdgeInsets.fromLTRB(30, 0, 30, 50),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.black, width:3),
              borderRadius: BorderRadius.circular(10),
              boxShadow: [
                BoxShadow(color: Colors.amberAccent, offset: Offset(6, 6)),
              ],
            ),
            child: Text(s1, style: TextStyle(fontSize: 20),),
          ),
          SizedBox(height: 15,),
          Container(
            color: Colors.redAccent,
            child: Image.asset('assets/ic.png'),
            height: 200,
            width: 200,
          ),
          SizedBox(height: 30,),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Container(
                width: 150,
                height: 150,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.purple, width:2, style: BorderStyle.solid),
                  borderRadius: BorderRadius.circular(30),
                  image: DecorationImage(image: AssetImage('assets/f1.jpg'),
                      fit: BoxFit.cover),
                ),
              ),
              SizedBox(width: 10,),
              Container(
                width: 150,
                height: 150,
                decoration: BoxDecoration(
                  border: Border.all(color: Colors.purple, width:2, style: BorderStyle.solid),
                  borderRadius: BorderRadius.circular(30),
                  image: DecorationImage(image: AssetImage('assets/yama.jpg'),
                      fit: BoxFit.cover),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class Screen2 extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
          children: [
            SizedBox(height: 10,),
            Container(
            color: Colors.redAccent,
            child: Image.asset('assets/chi.jpg'),
            height: 250,
            width: 400,
            ),
            Padding(
              padding: EdgeInsets.fromLTRB(20, 30, 20, 20),
              child: Text('Implement chess on fpga board', style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),),
            )
         ]
      ),
    );
  }
}

class Screen3 extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Text('大一時期', style: TextStyle(fontSize: 30,),),
            ],
          ),
          SizedBox(height: 1,),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Container(
                height: 200,
                width: 200,
                child: ListView(
                  children: [
                    Text('1. 打好基礎', style: TextStyle(fontSize: 15,),),
                    Text('2. 學會自學', style: TextStyle(fontSize: 15,),),
                    Text('3. 探索興趣', style: TextStyle(fontSize: 15,),),
                    Text('4. 參加活動', style: TextStyle(fontSize: 15,),),
                  ],
                ),
              ),
            ],
          ),
          SizedBox(height: 1,),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Text('大二時期', style: TextStyle(fontSize: 30,),),
            ],
          ),
          SizedBox(height: 1,),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Container(
                height: 200,
                width: 200,
                child: ListView(
                  children: [
                    Text('1. 深化知識', style: TextStyle(fontSize: 15,),),
                    Text('2. 參與實驗', style: TextStyle(fontSize: 15,),),
                    Text('3. 提高技能', style: TextStyle(fontSize: 15,),),
                    Text('4. 暑期實習', style: TextStyle(fontSize: 15,),),
                  ],
                ),
              ),
            ],
          ),
          SizedBox(height: 1,),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Text('大三時期', style: TextStyle(fontSize: 30,),),
            ],
          ),
          SizedBox(height: 1,),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Container(
                height: 200,
                width: 200,
                child: ListView(
                  children: [
                    Text('1. 加強實踐', style: TextStyle(fontSize: 15,),),
                    Text('2. 企業實習', style: TextStyle(fontSize: 15,),),
                    Text('3. 科研參與', style: TextStyle(fontSize: 15,),),
                    Text('4. 國際交流', style: TextStyle(fontSize: 15,),),
                  ],
                ),
              ),
            ],
          ),
          SizedBox(height: 1,),
          Row(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Text('大四時期', style: TextStyle(fontSize: 30,),),
            ],
          ),
          SizedBox(height: 1,),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Container(
                height: 200,
                width: 200,
                child: ListView(
                  children: [
                    Text('1. 整合所學', style: TextStyle(fontSize: 15,),),
                    Text('2. 完成專題', style: TextStyle(fontSize: 15,),),
                    Text('3. 求職準備', style: TextStyle(fontSize: 15,),),
                    Text('4. 證書考試', style: TextStyle(fontSize: 15,),),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class Screen4 extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Container(
        child: Text('Screen4'),
      ),
    );
  }
}
