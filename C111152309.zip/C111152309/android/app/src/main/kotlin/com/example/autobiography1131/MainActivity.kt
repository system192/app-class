package com.example.autobiography1131

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
